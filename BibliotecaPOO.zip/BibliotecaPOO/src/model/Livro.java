package model;

public class Livro extends ItemBiblioteca {
    private String editora;

    public Livro(String titulo, String autor, int ano, String editora) {
        super(titulo, autor, ano);
        this.editora = editora;
    }

    @Override
    public void exibirDetalhes() {
        System.out.println("Livro: " + titulo + ", Autor: " + autor + ", Ano: " + ano + ", Editora: " + editora);
    }
}