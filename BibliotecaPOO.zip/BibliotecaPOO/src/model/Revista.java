package model;

public class Revista extends ItemBiblioteca {
    private int edicao;

    public Revista(String titulo, String autor, int ano, int edicao) {
        super(titulo, autor, ano);
        this.edicao = edicao;
    }

    @Override
    public void exibirDetalhes() {
        System.out.println("Revista: " + titulo + ", Autor: " + autor + ", Ano: " + ano + ", Edição: " + edicao);
    }
}