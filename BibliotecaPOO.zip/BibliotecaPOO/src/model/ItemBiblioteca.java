package model;

public abstract class ItemBiblioteca implements Exibivel {
    protected String titulo;
    protected String autor;
    protected int ano;

    public ItemBiblioteca(String titulo, String autor, int ano) {
        if (titulo == null || titulo.isEmpty()) throw new IllegalArgumentException("Título não pode ser vazio");
        this.titulo = titulo;
        this.autor = autor;
        this.ano = ano;
    }

    public String getTitulo() {
        return titulo;
    }
}