package model;

public class CampoVazioException extends Exception {
    public CampoVazioException(String campo) {
        super("O campo '" + campo + "' está vazio.");
    }
}