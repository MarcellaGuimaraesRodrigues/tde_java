package model;

public interface Exibivel {
    void exibirDetalhes();
}