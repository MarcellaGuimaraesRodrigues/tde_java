package view;

import controller.BibliotecaController;
import model.*;

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BibliotecaController controller = new BibliotecaController();

        int opcao;

        do {
            System.out.println("\n=== Sistema de Biblioteca ===");
            System.out.println("1. Adicionar item");
            System.out.println("2. Listar itens");
            System.out.println("3. Buscar item por título");
            System.out.println("4. Remover item");
            System.out.println("0. Sair");
            System.out.print("Opção: ");
            opcao = Integer.parseInt(scanner.nextLine());

            try {
                switch (opcao) {
                    case 1 -> {
                        System.out.println("Tipo (1=Livro, 2=Revista, 3=Trabalho Acadêmico): ");
                        int tipo = Integer.parseInt(scanner.nextLine());

                        System.out.print("Título: ");
                        String titulo = scanner.nextLine();
                        if (titulo.isEmpty()) throw new CampoVazioException("Título");

                        System.out.print("Autor: ");
                        String autor = scanner.nextLine();

                        System.out.print("Ano: ");
                        int ano = Integer.parseInt(scanner.nextLine());

                        switch (tipo) {
                            case 1 -> {
                                System.out.print("Editora: ");
                                String editora = scanner.nextLine();
                                controller.adicionarItem(new Livro(titulo, autor, ano, editora));
                            }
                            case 2 -> {
                                System.out.print("Edição: ");
                                int edicao = Integer.parseInt(scanner.nextLine());
                                controller.adicionarItem(new Revista(titulo, autor, ano, edicao));
                            }
                            case 3 -> {
                                System.out.print("Instituição: ");
                                String instituicao = scanner.nextLine();
                                controller.adicionarItem(new TrabalhoAcademico(titulo, autor, ano, instituicao));
                            }
                            default -> System.out.println("Tipo inválido.");
                        }
                    }

                    case 2 -> controller.listarItens();

                    case 3 -> {
                        System.out.print("Digite o título para busca: ");
                        String tituloBusca = scanner.nextLine();
                        controller.buscarPorTitulo(tituloBusca).exibirDetalhes();
                    }

                    case 4 -> {
                        System.out.print("Digite o título do item a remover: ");
                        String tituloRemover = scanner.nextLine();
                        controller.removerItem(tituloRemover);
                    }

                    case 0 -> System.out.println("Encerrando...");
                    default -> System.out.println("Opção inválida.");
                }
            } catch (CampoVazioException | ItemNaoEncontradoException e) {
                System.out.println("Erro: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("Erro inesperado: " + e.getMessage());
            }

        } while (opcao != 0);

        scanner.close();
    }
}